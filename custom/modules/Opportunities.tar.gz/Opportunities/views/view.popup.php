<?php


require_once ("include/MVC/View/views/view.popup.php");

class CustomOpportunitiesViewPopup extends ViewPopup
{

    // function preDisplay(){
    //     echo "hi";
    //     parent::preDisplay();
    // }

}