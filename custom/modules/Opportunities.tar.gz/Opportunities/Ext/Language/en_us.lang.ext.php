<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_USERS_1_FROM_USERS_TITLE'] = 'Tag Users';
$mod_strings['LBL_OPPORTUNITIES_USERS_2_FROM_USERS_TITLE'] = 'Untag Users';
$mod_strings['LBL_OPPORTUNITIES_DOCUMENTS_1_FROM_DOCUMENTS_TITLE'] = 'Documents';


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_USERS_1_FROM_USERS_TITLE'] = 'Tag Users';


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_USERS_1_FROM_USERS_TITLE'] = 'Tag Users';
$mod_strings['LBL_OPPORTUNITIES_USERS_2_FROM_USERS_TITLE'] = 'Untag Users';



$mod_strings[‘LBL_FILE_MIME_TYPE’] = 'File Mime Type';

$mod_strings[‘LBL_FILE_URL’] = 'File URL';

$mod_strings[‘LBL_FILENAME’] = 'UploadFile';


?>