//  $('.notCurrentTab').hide();

// $(document).on("load", function(event){
// //   // console.log("hello");
// //  // alert('in')
//  $('#check a').hide();
// //  $().hide();
// console.log("outer hide");
// //  $(document).on("load", "#check a", function(event){
// //      $(this).hide();
     
// //     console.log("hide");
// // });
// });

// $( window ).load(function() {
//   console.log('sdhasha');
// });

$( document ).ready(function() {
    
     setTimeout(function() {
      $('#check a').hide();
      console.log('sad');
 }, 10);
 
 $('.suitepicon-action-info').hide();
 
});
